void main() {
    int a, b, c, d, e;

    a = 100;
    b = 75;
    c = 50;
    d = 25;
    e = 0;

    while ( a > b ) {
        while (b > c) {
            while (c > d) {
                do {
                    e = e + 1;
                } while (d > e);
                d = d + 1;
            }
            c = c + 1;
        }
        b = b + 1;
    }

}