int count;
void main(){

int variable1,variable2,variable3,variable4;
bool variable10;
variable1 = 10;
variable2 = 10;
variable3 = 13;
variable4 = 10;
variable10 = 5<9;
count = 2;
while (variable1>variable3 && variable2 <= variable4?variable3<variable4:variable2<variable4){
	
	print "The statement is correct\n";
	do{
	variable3 = variable3+count;
	print " ";
	print variable3;
	
	}	while(variable3 < variable1 || variable1 >= variable4 || variable10);
	count = count + 1;
	
	
}


}
