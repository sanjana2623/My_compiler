int count;

void main()
{
	int number,a;
	count = 0 ;
	number = 0;
	while(number <= 100)
	{   

		if ((number/7)*7 == number && number >= 7){
			count = count + 1;
		}
		number = number+1;
	}
	print "No of multiples of 7, less than 100 ";
	print count;
	
	
	
}
