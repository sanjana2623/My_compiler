int global_variable1;
void main()
{
int variable1, variable2, variable3;
string string_variable1;

read variable1; 
read variable2;
read variable3;
read global_variable1;

while(global_variable1 > 0)
{ 
	variable3 = (variable2 - variable1) * (variable1 + variable3 / variable2);
	global_variable1 = global_variable1 - 2;  
}

if(global_variable1 < 0)
{
	string_variable1 = "Passed";
}

else
{
	string_variable1 = "Failed";
}

print variable3;
print string_variable1;
 
}
