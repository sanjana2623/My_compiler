void main() {
    int a, b, c, d, e, q;
    string str;

    a = 100;
    b = 75;
    c = 50;
    d = 25;
    e = 0;

    str = "Hello";

    if (a < b) {
        a = a + 1;
    } else {
        if (b < c) {

        } else {
            while (a > b) {
                b = b + 1;
            }
            do {
                q = a / 2;
                if (q * 2 == a) {
                    b = b + 2;
                    a = a + 1;
                } else {
                    if (c > d || d > e || a > b) {
                        d = d + 1;
                    } 
                }
            } while (b > c);
        }
    }

}