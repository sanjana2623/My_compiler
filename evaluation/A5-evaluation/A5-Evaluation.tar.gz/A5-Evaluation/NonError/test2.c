int global_variable1;
void main()
{
int variable1, variable2, variable3;
string string_variable1;

read variable1; 
read variable2;
read variable3;
read global_variable1;

do
{
	variable2 = variable2 + (variable3 - variable1)*(variable3 + variable1);
	if(variable2 < 10)
	{
		variable2 = variable2 + 2;
	}
	global_variable1 = global_variable1 + 4;	
}
while(global_variable1 < 10);

if(variable3 > 0)
{
	if(variable2 > 2)
	{
		string_variable1 = "Passed";
	}
	
	else
	{
		string_variable1 = "Failed";
	}
	
}

print string_variable1;
}
