void main()
{
    int x,y,z,a,b,count,while_ans;
    x = 10;
    y = 20;
    count = 0;
    read a;
    read b;

    if(x > y)
    {
        z = x*x - y*y;
    }
    else{
        z = y*y - x*x;
    }

    do
    {
        count = count + 1;
        while_ans = while_ans + (a + b)*(a*a + a*b + b*b);
    }while(count < z);
    print while_ans;
}