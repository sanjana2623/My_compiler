void main()
{
    while(1==1)
    {
        print "hello";
    }
}