void main()
{
    int local_int_1,local_int_2,local_int_3;
    local_int_1 = 100;
    local_int_2= 1000;
    local_int_3 = 0;
    while(local_int_1>0)
    {
    	local_int_1=local_int_1-1;
    	while(local_int_2>0)
    	{
    		local_int_2=local_int_1-10;
    		while(local_int_3<100)
    		{
    			local_int_3=local_int_3+1;
				if(1==1)
				{
					local_int_1=local_int_1-1;
				}
    		}		
    	}
    }   
	do
	{
		local_int_1=local_int_1*2;
	} while (local_int_3>local_int_1);
}
